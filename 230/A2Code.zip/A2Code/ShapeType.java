/*
 *  ============================================================================================
 *  enum which defines the type of shapes in A1
 *  Brendan Choi
 *  YOUR UPI: mcho868
 *  ============================================================================================
 */
import java.util.*;
enum ShapeType { RECTANGLE, OVAL, OCTAGON;}